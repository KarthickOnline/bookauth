import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  bookForm: FormGroup;
  myBooks: { bookid: any; bookname: any; author: any; }[] = [];

  constructor(public _book: BookService) { }

  ngOnInit(): void {
    this.bookForm = new FormGroup({
      'bookname': new FormControl(null),
      'bookid': new FormControl(null),
      'author': new FormControl(null),
    });
  }

  // ngOnInit(): void { }
  // bookForm = new FormGroup({
  //   'bookname': new FormControl(null),
  //   'bookid': new FormControl(null),
  //   'author': new FormControl(null),
  // });

  onPushBook() {
    const bookid = this.bookForm.get('bookid').value;
    const bookname = this.bookForm.get('bookname').value;
    const author = this.bookForm.get('author').value;

    this.myBooks.push({
      bookid: bookid,
      bookname: bookname,
      author: author,
    });
  }

  onSave() {
    this._book.saveBook(this.myBooks)
      .subscribe({
        next: sub => { console.log(sub); },
        error: error => { console.log(error); },
      })
  }

  onGet() {
    this._book.getBook()
      .subscribe({
        next: sub => { console.log(sub); },
        error: err => { console.log(err); },
      })
  }
}
