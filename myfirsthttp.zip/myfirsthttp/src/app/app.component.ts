import { Component, OnInit } from '@angular/core';
import firebase from "firebase/compat/app";
import "firebase/auth";
//
// import { initializeApp } from 'firebase/app';
// import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'myfirsthttp';

  ngOnInit(): void {
    const firebaseConfig = {
      apikey: "AIzaSyAzmzHNkhPykC1L3YN_pCuzqw3_Plizr4E",
    };

    firebase.initializeApp(firebaseConfig);
    // const app = initializeApp(firebaseConfig);
    // initializeApp(firebaseConfig);
  }
}
