import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private _http: HttpClient) { }

  saveBook(books: any[]): Observable<any> {
    return this._http.post("https://demomamey-default-rtdb.firebaseio.com/data.json", books);
  }

  getBook(): Observable<any>{
    return this._http.get("https://demomamey-default-rtdb.firebaseio.com/data.json")
  }
}