import { Injectable } from '@angular/core';
import firebase from 'firebase/compat/app';
import "firebase/auth";
// import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  RegisterUser(email: string, password: string) {
    firebase.auth().createUserWithEmailAndPassword(email, password)
      .then(resp => {
        console.log(resp);
      })
      .catch(error => {
        console.log(error);
      });
  }

  // RegisterUser(email: string, password: string) {
  //   const auth = getAuth();
  //   createUserWithEmailAndPassword(auth, email, password)
  //     .then(resp => {
  //       console.log(resp);
  //     })
  //     .catch(error => {
  //       console.log(error);
  //     });
  // }
}
